insert INTO job (job_title)
VALUES ('Web Programmer'); 