delete from job
where job_title_id = 11;