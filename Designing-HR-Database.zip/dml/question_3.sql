update job
set job_title = 'Web Developer'
where job_title_id = 11;